exports.handler = function(event, context) { 
    console.log("Hello World NodeJS");
}
